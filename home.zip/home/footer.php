<body>
    <footer class="text-white pt-5 pb-4">
        <div class="container text-center text-md-left">
            <hr class="mb-6">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <p>Copyright &copy;2024 All rights reserved by
                        <a href="#" style="text-decoration: none;"><br>
                            <strong style="color: #fff;">sL Code <span style="color: red;">Hub</span></strong>
                        </a>
                    </p>
                </div>
            </div>
        </div>
    </footer>
</body>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "../head.php"; ?>
    <title>sL Code Hub | Home</title>
</head>

<body>
    <!-- navbar -->
    <?php include "navbar.php"; ?>


    

    <!-- footer -->
    <?php include "footer.php"; ?>

    <?php include "../script.php"; ?>
</body>

</html>